# -----------------------------------------------------------------------------------
# Imports
# -----------------------------------------------------------------------------------

from RegistroTamanhoFixo import *

# -----------------------------------------------------------------------------------
# Função: principal (main)
# -----------------------------------------------------------------------------------

if __name__ == "__main__":
    
    # # Abrindo o arquivo fonte
    # f = open("animes.csv", mode="r", encoding="utf-8")
    
    # # Lendo todos os registros e armazenando em uma lista (registrosAnime)
    # registrosAnimes = f.readlines()
    
    # #removendo o cabeçalho (header)
    # registrosAnimes.pop(0)
    
    # # fechando o arquivo
    # f.close()
    
    # # realizando a escrita dos registros em um arquivo com registros de tamanho fixo,
    # #  e campos de tamanhos variados
    # EscritaRegistrosFixosCamposVariados(registrosAnimes=registrosAnimes, 
    #     arquivoSaida="fixedLength.txt", debugging=True)
    
    # ---------------------
    # ---------------------
    
    # Abrindo o arquivo com registros de tamanho fixo e campos variados
    fr = open("fixedLength.txt", mode="r", encoding="utf-8")

    # descobrindo o tamanho do registro    
    reg = fr.readline()
    
    # descobrindo o numero de linhas do 
    SIZE = len(reg)

    # Tentando ler todos os exemplos (0, linhas - 2)
    for i in range(0, 100):
        reg = LeituraRegistrosFixosCamposVariados(arquivoDados=fr, tamanhoRegistro=SIZE, RRN=i)
        print(reg)
    
    
# -----------------------------------------------------------------------------------
# -----------------------------------------------------------------------------------

