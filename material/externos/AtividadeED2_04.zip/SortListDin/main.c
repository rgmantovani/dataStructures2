#include <stdio.h>
#include <stdlib.h>
#include "ListaDinEncad.h"
int main(){
    struct aluno a[4] = {{2,"Andre",9,7,8},
                         {4,"Ricardo",7,8,6},
                         {1,"Bianca",9,6,8},
                         {3,"Ana",5,6,7}};
    Lista* li = cria_lista();

    int i;
    for(i=0; i < 4; i++)
        insere_lista_inicio(li,a[i]);

    imprime_lista(li);

    libera_lista(li);
    system("pause");
    return 0;
}

